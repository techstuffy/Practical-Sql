-- LEN

select len(category) as len ,category
from [first_db].[dbo].[spending_initial]
GROUP BY category


-- CHARINDEX

select charindex('o',category) as char_index, category
from [first_db].[dbo].[spending_initial]
GROUP BY category



-- LEFT \ RIGHT

select left(category,3) as read_left, category
from [first_db].[dbo].[spending_initial]
GROUP BY category



-- SUBSTRING

select substring(category,2,3) as read_left, category
from [first_db].[dbo].[spending_initial]
GROUP BY category



-- LTRIM\RTRIM

select DATALENGTH(LTRIM(' my teststring ')) as result

-- UPPER\LOWER

select UPPER('MaRk')

-- CONCAT

select CONCAT('My ','name ', 'is ', 'mark')

-- REPLACE

select REPLACE(category,'O','o') as replace_string, category
from [first_db].[dbo].[spending_initial]
GROUP BY category
