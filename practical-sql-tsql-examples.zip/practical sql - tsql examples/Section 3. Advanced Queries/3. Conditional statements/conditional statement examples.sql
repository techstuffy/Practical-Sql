

-- IF 

IF ( SELECT DATEPART(hour,GETDATE()) )>12 
BEGIN
	PRINT 'Good Afternoon'
END



-- IF THEN ELSE

IF (SELECT DATEPART(hour,GETDATE()))>12 
BEGIN
	PRINT 'Good Afternoon'
END
ELSE
BEGIN
	PRINT 'Good Morning'
END

-- CASE

SELECT 
(CASE
	WHEN DATEPART(hour,GETDATE()) > 12 
	THEN
		'Good Afternoon'
END)  as current_message
