
-- Filtering Aggregation Functions

SELECT sum(amount)  as spending_total,category
  FROM [first_db].[dbo].[spending_initial]
GROUP BY category
HAVING sum(amount)>5


-- Filtering Aggregation Functions - ERROR


SELECT sum(amount)  as spending_total,category
  FROM [first_db].[dbo].[spending_initial]
GROUP BY category
HAVING amount>5
