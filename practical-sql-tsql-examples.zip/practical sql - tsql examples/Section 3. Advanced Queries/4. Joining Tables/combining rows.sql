-- Create a new table 

CREATE TABLE [dbo].[spending_more](
	[created_date] [date] NOT NULL,
	[category] [varchar](20) NOT NULL,
	[amount ] [numeric](5, 2) NOT NULL,
	[user_id] [int] NULL

-- Union 

SELECT * FROM [first_db].[dbo].[spending_initial]
UNION
SELECT * FROM [first_db].[dbo].[spending_more]

-- Except

SELECT * FROM [first_db].[dbo].[spending_initial]
EXCEPT
SELECT * FROM [first_db].[dbo].[spending_more]


-- Intersect

SELECT * FROM  [dbo].[spending_initial]
INTERSECT
SELECT * FROM [dbo].[spending_more]
