-- Create example sample data

-- Create new table

CREATE TABLE [dbo].[spending_users](
	[user_id] [int] NOT NULL,
	[firstname] [varchar](20) NOT NULL,
	[lastname] [varchar](20) NOT NULL,
	[department] [varchar](50) NOT NULL,
	[budget] [numeric](5, 2) NOT NULL

-- Insert data into new table

INSERT INTO [dbo].[spending_users]
      ([user_id],[firstname],[lastname],[department],[budget])
     	VALUES
           (1,'Joe','Blogs','Sales',100)
GO


----------------------

-- Inner Join

SELECT *
  FROM [first_db].[dbo].[spending_initial]
  INNER JOIN [dbo].[spending_users]
  ON [spending_initial].user_id = [spending_users].user_id


-- Left outer join

SELECT *
  FROM [first_db].[dbo].[spending_initial] spent
  LEFT OUTER JOIN [dbo].[spending_users] users
  ON spent.user_id = users.user_id


-- Right outer join

SELECT *
  FROM [first_db].[dbo].[spending_initial] spent
  RIGHT OUTER JOIN [dbo].[spending_users] users
  ON spent.user_id = users.user_id


-- Full outer join

SELECT *
  FROM [first_db].[dbo].[spending_initial] spent
  FULL OUTER JOIN [dbo].[spending_users] users
  ON spent.user_id = users.user_id

 -- Cross join

SELECT * FROM [first_db].[dbo].[spending_initial] spent
  CROSS JOIN [dbo].[spending_users] users

-- Multiple joins

SELECT * FROM [first_db].[dbo].[spending_initial] spent
  RIGHT JOIN [dbo].[spending_users] users
 	 ON spent.user_id = users.user_id
  LEFT JOIN [dbo].[another_table] another
 	 ON another.user_id = users.user_id  


