
-- Insert

USE [first_db]
GO
INSERT INTO [dbo].[spending_initial]
	([created_date],[category],[amount])
	VALUES ('1/9/13','OTHER','15.20')
 


-- Select

SELECT TOP 1000 [created_date]
      ,[category]
      ,[amount ]
  FROM [first_db].[dbo].[spending_initial]


-- Update

UPDATE [spending_initial]
  		SET category='FOOD'
		WHERE category='LUNCH'


-- Delete

DELETE FROM [spending_initial]
  		WHERE category='OTHER'
