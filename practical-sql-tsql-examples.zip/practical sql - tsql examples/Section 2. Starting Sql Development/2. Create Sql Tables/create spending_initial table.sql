use first_db
CREATE TABLE [dbo].[spending_initial](
	[created_date] [date] NOT NULL,
	[category] [varchar](20) NOT NULL,
	[amount ] [numeric](5,2) NOT NULL
