--- Numeric calculation error - divide by 
BEGIN TRY
	BEGIN TRANSACTION
		PRINT 'STATEMENT 1'
		INSERT INTO [dbo].[spending_initial]
					([created_date],[category],[amount],[user_id],[fk_category])
			 VALUES ('4/4/13','CLOTHES',100,2,0)

		--Statement that causes an error
		select 1/0 as result
		PRINT 'STATEMENT 2'
		INSERT INTO [dbo].[spending_audit]
					([audit_category],[message],[created_dttm])
	VALUES ('SPENDING','An expense has been added',GETDATE())
	COMMIT TRANSACTION
END TRY
BEGIN CATCH
	PRINT 'ERROR'
	SELECT * FROM spending_audit
	ROLLBACK TRANSACTION
END CATCH
