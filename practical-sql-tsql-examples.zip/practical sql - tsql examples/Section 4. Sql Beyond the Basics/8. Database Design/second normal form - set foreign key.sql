UPDATE spending_initial
set fk_category=
(select id from [dbo].[spending_category] where spending_initial.category=spending_category.category)
