ALTER PROCEDURE [dbo].[usp_myfirstsp]
(
	@filter_category varchar(20) 
)
AS
BEGIN
	SET NOCOUNT ON;
	SELECT * FROM [first_db].[dbo].[spending_initial]	 
	WHERE category=@filter_category
	UNION
	SELECT * FROM [first_db].[dbo].[spending_more]
	WHERE category=@filter_category
END
