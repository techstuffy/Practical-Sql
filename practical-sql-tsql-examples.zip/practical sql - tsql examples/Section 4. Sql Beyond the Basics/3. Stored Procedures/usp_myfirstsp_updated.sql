USE [first_db]
GO
/****** Object:  StoredProcedure [dbo].[usp_myfirstsp]    Script Date: 22/01/2013 21:23:02 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Mark O'Donovan
-- Create date: 31/12/2012
-- Description:	My first stored procedure
-- =============================================
ALTER PROCEDURE [dbo].[usp_myfirstsp]
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	SELECT * FROM [first_db].[dbo].[spending_initial]
	UNION
	SELECT * FROM [first_db].[dbo].[spending_more]
END
