SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author: Mark O'Donovan
-- Create date: 31/12/2012
-- Description: My first stored procedure
-- =============================================
CREATE PROCEDURE usp_myfirstsp
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	SELECT * FROM [first_db].[dbo].[spending_initial]
	UNION
	SELECT * FROM [first_db].[dbo].[spending_more]
END
GO
