--This will return data about the user and their spending
CREATE FUNCTION fn_getuser_spending
(
	@user_id int
)
RETURNS 
@spending TABLE 
(
	username varchar(40) NOT NULL
	,category varchar(20) NOT NULL
	,amount numeric(5,2) NOT NULL
)
AS
BEGIN
	DECLARE @username varchar(40), @category varchar(20), @amount numeric(5,2)
	--Get the username 
	SELECT @username= [firstname] +' '+[lastname] from [dbo].[spending_users]
	WHERE user_id=@user_id 
	SELECT 
		@category =  category
		,@amount = amount
		FROM [dbo].[spending_initial]
		WHERE user_id=@user_id

INSERT @spending
	SELECT @username,@category,@amount
	RETURN 
END
GO
