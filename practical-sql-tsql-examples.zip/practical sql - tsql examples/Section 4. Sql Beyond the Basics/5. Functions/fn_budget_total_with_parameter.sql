ALTER FUNCTION fn_budget_total 
(
	@dept varchar(50)	 
)
RETURNS numeric(5,2)
AS
BEGIN
	DECLARE  @budgettotal numeric(5,2)

	SELECT  @budgettotal=SUM(budget) from [dbo].[spending_users]
	where department=@dept
 
	RETURN @budgettotal
END
GO
