SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Your Name
-- Create date: Current Date
-- Description:	Return the budget total
-- =============================================
CREATE FUNCTION fn_budget_total 
(
	-- Add the parameters for the function here	 
)
RETURNS 
AS
BEGIN
	-- Declare the return variable here
	DECLARE  

	-- Add the T-SQL statements to compute the return value here
	SELECT  = 

	-- Return the result of the function
	RETURN 

END
GO
