
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Your Name
-- Create date: 	Created Date
-- Description:	Rows for department
-- =============================================
CREATE FUNCTION fn_dept_users 
(	
	-- Add the parameters for the function here
	@dept varchar(50)	 
)
RETURNS TABLE 
AS
RETURN 
(
	-- Add the SELECT statement with parameter references here
	SELECT 0
)
GO
