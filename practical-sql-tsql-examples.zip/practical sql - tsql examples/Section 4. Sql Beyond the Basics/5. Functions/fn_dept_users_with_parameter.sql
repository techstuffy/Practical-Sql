SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Your Name
-- Create date: 	Created Date
-- Description:	Rows for department
-- =============================================
CREATE FUNCTION fn_dept_users 
(	
	-- Add the parameters for the function here
	@dept varchar(50)	 
)
RETURNS TABLE 
AS
RETURN 
(
	 select  
		[user_id]
      ,[firstname]
      ,[lastname]
      ,[department]
      ,[budget]
  FROM [first_db].[dbo].[spending_users]
  WHERE department=@dept
)
GO
