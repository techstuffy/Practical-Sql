CREATE TRIGGER dbo.trig_spending_users_insert 
   ON  dbo.spending_users 
   INSTEAD OF INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for trigger here
	INSERT INTO [dbo].[spending_audit]([audit_category],[message],[created_dttm])
	VALUES ('USERS','prevented from adding user '+ (SELECT inserted.firstname + ' '+inserted.lastname FROM INSERTED),GETDATE())

END
