use first_db
CREATE TABLE [dbo].[spending_audit](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[audit_category] [varchar](100) NULL,
	[message] [varchar](max) NULL,
	[created_dttm] [datetime] NULL,
)
