
CREATE TRIGGER trig_create_table ON DATABASE 
FOR CREATE_TABLE
AS
BEGIN
	PRINT 'You are not allowed to create tables'
	ROLLBACK;
INSERT INTO [dbo].[spending_audit]([audit_category],[message],[created_dttm])
	VALUES ('TABLE','prevented from creating table',GETDATE())
END
