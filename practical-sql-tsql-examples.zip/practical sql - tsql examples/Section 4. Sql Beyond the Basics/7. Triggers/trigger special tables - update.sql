ALTER TRIGGER dbo.trig_spending_initial_update
   ON  dbo.spending_initial
   AFTER UPDATE
AS 
BEGIN
	SET NOCOUNT ON;
	DECLARE @new_amount numeric(5,2)
	DECLARE @old_amount numeric(5,2)
	DECLARE @category varchar(20)

	SELECT @old_amount=deleted.amount from DELETED
	SELECT @new_amount=inserted.amount,@category=inserted.category from INSERTED

	INSERT INTO [dbo].[spending_audit]([audit_category],[message],[created_dttm])
	VALUES ('AMOUNT UPDATE','updated category '+@category+ ' amount from '+cast(@old_amount as varchar(10))+' to '+
	cast(@new_amount as varchar(10)) ,GETDATE())
END
