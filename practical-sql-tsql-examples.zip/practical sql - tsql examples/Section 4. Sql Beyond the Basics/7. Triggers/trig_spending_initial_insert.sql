SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Your name
-- Create date: 	Created Date
-- Description:	Add audit log when insert spending
-- =============================================
CREATE TRIGGER dbo.trig_spending_initial_insert 
   ON  dbo.spending_initial 
   AFTER INSERT
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    -- Insert statements for trigger here
	INSERT INTO [dbo].[spending_audit]([audit_category],[message],[created_dttm])
	VALUES ('SPENDING','row added for category '+ (SELECT inserted.category FROM INSERTED),GETDATE())
END
GO
