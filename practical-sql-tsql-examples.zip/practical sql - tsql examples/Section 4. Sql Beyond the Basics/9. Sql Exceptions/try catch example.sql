
--- Numeric calculation error - divide by 
BEGIN TRY
	PRINT 'START'
	select 1/0 as result
	PRINT 'END'
END TRY

BEGIN CATCH
	PRINT 'ERROR'
END CATCH

