CREATE VIEW [dbo].[spending_all]
AS
SELECT        created_date, category, amount, user_id
FROM            dbo.spending_initial
